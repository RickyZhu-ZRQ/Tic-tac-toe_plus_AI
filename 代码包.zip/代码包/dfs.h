#include<utility>

std::pair<int, int>find(int[3][3]);
